#!/usr/bin/env python3
"""
Ubuntu Server Control Bot — modular entry point.
Run:  python3 bot.py
"""

import asyncio

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config import API_TOKEN, logger
from database import init_db
from utils import AuthMiddleware
from handlers import register_all_handlers
from monitors import start_all_monitors


def create_bot() -> Bot:
    return Bot(
        token=API_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


async def main() -> None:
    init_db()

    bot = create_bot()
    dp = Dispatcher()

    # Auth middleware — blocks all non-authorized users
    dp.message.middleware(AuthMiddleware())

    # Register handler routers
    register_all_handlers(dp)

    # Start background monitors on bot startup
    @dp.startup()
    async def on_startup(_bot: Bot):
        start_all_monitors(_bot)
        logger.info("Bot started, all monitors running")

    logger.info("Starting polling…")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
