import sqlite3
import time
from config import DB_FILE, DATA_RETENTION_DAYS, logger


def _conn() -> sqlite3.Connection:
    return sqlite3.connect(DB_FILE)


def init_db() -> None:
    conn = _conn()
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS metrics (
        timestamp REAL, cpu REAL, ram REAL, temp REAL,
        net_sent REAL, net_recv REAL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS ssh_events (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp REAL,
        event_type TEXT,
        username  TEXT,
        ip        TEXT,
        method    TEXT
    )""")

    # Migration: add columns for extended SSH info
    for col, col_type, default in [
        ("port", "INTEGER", "0"),
        ("key_fingerprint", "TEXT", "''"),
        ("invalid_user", "INTEGER", "0"),
    ]:
        try:
            c.execute(f"ALTER TABLE ssh_events ADD COLUMN {col} {col_type} DEFAULT {default}")
        except sqlite3.OperationalError:
            pass  # column already exists

    c.execute("CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics(timestamp)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_ssh_ts     ON ssh_events(timestamp)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_ssh_ip     ON ssh_events(ip)")

    conn.commit()
    conn.close()
    logger.info("Database initialized")


# ── Metrics ──────────────────────────────────────────────

def insert_metric(ts, cpu, ram, temp, net_sent, net_recv) -> None:
    conn = _conn()
    conn.execute(
        "INSERT INTO metrics VALUES (?,?,?,?,?,?)",
        (ts, cpu, ram, temp, net_sent, net_recv),
    )
    conn.commit()
    conn.close()


def get_metrics(since_ts: float) -> list:
    conn = _conn()
    rows = conn.execute(
        "SELECT * FROM metrics WHERE timestamp > ? ORDER BY timestamp ASC",
        (since_ts,),
    ).fetchall()
    conn.close()
    return rows


# ── SSH events ───────────────────────────────────────────

def insert_ssh_event(
    ts: float,
    event_type: str,
    username: str,
    ip: str,
    method: str,
    port: int = 0,
    key_fingerprint: str = "",
    invalid_user: bool = False,
) -> None:
    conn = _conn()
    conn.execute(
        "INSERT INTO ssh_events "
        "(timestamp, event_type, username, ip, method, port, key_fingerprint, invalid_user) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (ts, event_type, username, ip, method, port, key_fingerprint, int(invalid_user)),
    )
    conn.commit()
    conn.close()


def get_ssh_events(limit: int = 30) -> list:
    conn = _conn()
    rows = conn.execute(
        "SELECT timestamp, event_type, username, ip, method, "
        "port, key_fingerprint, invalid_user "
        "FROM ssh_events ORDER BY timestamp DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return rows


def get_ssh_count() -> tuple[int, int, int]:
    """Returns (total, accepted, failed) across all time."""
    conn = _conn()
    c = conn.cursor()
    total = c.execute("SELECT COUNT(*) FROM ssh_events").fetchone()[0]
    accepted = c.execute(
        "SELECT COUNT(*) FROM ssh_events WHERE event_type='accepted'"
    ).fetchone()[0]
    failed = c.execute(
        "SELECT COUNT(*) FROM ssh_events WHERE event_type='failed'"
    ).fetchone()[0]
    conn.close()
    return total, accepted, failed


def get_failed_ssh_stats(hours: int = 24) -> tuple[int, int]:
    """Returns (total_failed, unique_ips) for the last N hours."""
    since = time.time() - hours * 3600
    conn = _conn()
    row = conn.execute(
        "SELECT COUNT(*), COUNT(DISTINCT ip) "
        "FROM ssh_events WHERE event_type='failed' AND timestamp > ?",
        (since,),
    ).fetchone()
    conn.close()
    return row[0], row[1]


def get_top_failed_ips(hours: int = 24, limit: int = 5) -> list:
    """Top attacker IPs: [(ip, count), ...]"""
    since = time.time() - hours * 3600
    conn = _conn()
    rows = conn.execute(
        "SELECT ip, COUNT(*) as cnt FROM ssh_events "
        "WHERE event_type='failed' AND timestamp > ? "
        "GROUP BY ip ORDER BY cnt DESC LIMIT ?",
        (since, limit),
    ).fetchall()
    conn.close()
    return rows


def get_usernames_tried(hours: int = 24, limit: int = 10) -> list:
    """Most targeted usernames: [(username, count), ...]"""
    since = time.time() - hours * 3600
    conn = _conn()
    rows = conn.execute(
        "SELECT username, COUNT(*) as cnt FROM ssh_events "
        "WHERE event_type='failed' AND timestamp > ? "
        "GROUP BY username ORDER BY cnt DESC LIMIT ?",
        (since, limit),
    ).fetchall()
    conn.close()
    return rows


def clear_ssh_events() -> int:
    """Delete ALL ssh_events. Returns removed count."""
    conn = _conn()
    count = conn.execute("SELECT COUNT(*) FROM ssh_events").fetchone()[0]
    conn.execute("DELETE FROM ssh_events")
    conn.commit()
    conn.close()
    return count


# ── Maintenance ──────────────────────────────────────────

def cleanup_old_data() -> int:
    cutoff = time.time() - DATA_RETENTION_DAYS * 86400
    conn = _conn()
    c = conn.cursor()
    c.execute("DELETE FROM metrics    WHERE timestamp < ?", (cutoff,))
    m = c.rowcount
    c.execute("DELETE FROM ssh_events WHERE timestamp < ?", (cutoff,))
    s = c.rowcount
    conn.commit()
    conn.close()
    total = m + s
    if total:
        logger.info(f"Cleanup: removed {m} metrics + {s} ssh_events older than {DATA_RETENTION_DAYS}d")
    return total
