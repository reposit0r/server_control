import asyncio
import collections
import time

import psutil
from aiogram import Bot

from config import (
    AUTHORIZED_USER_ID,
    THRESHOLDS,
    METRICS_INTERVAL,
    DB_SAVE_INTERVAL,
    logger,
)
from database import insert_metric, cleanup_old_data
from utils import get_cpu_temp

# Rolling history for smoothed alerting
_history: dict[str, collections.deque] = {
    "CPU":  collections.deque(maxlen=120),
    "RAM":  collections.deque(maxlen=120),
    "TEMP": collections.deque(maxlen=120),
}
_notified: dict[str, bool] = {"CPU": False, "RAM": False, "TEMP": False}


async def metrics_loop(bot: Bot) -> None:
    net = psutil.net_io_counters()
    last_net = {"sent": net.bytes_sent, "recv": net.bytes_recv, "time": time.time()}
    last_save = time.time()
    last_cleanup = time.time()

    while True:
        try:
            now = time.time()
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            temp = get_cpu_temp() or 0.0

            _history["CPU"].append(cpu)
            _history["RAM"].append(ram)
            _history["TEMP"].append(temp)

            # ── Smoothed alerts ──
            n = max(1, THRESHOLDS["AVG_TIME"] // METRICS_INTERVAL)
            for key in ("CPU", "RAM", "TEMP"):
                vals = list(_history[key])[-n:]
                avg = sum(vals) / len(vals)
                if avg >= THRESHOLDS[key] and not _notified[key]:
                    await bot.send_message(
                        AUTHORIZED_USER_ID,
                        f"⚠️ High <b>{key}</b>: {round(avg, 1)} "
                        f"(avg {THRESHOLDS['AVG_TIME']}s)",
                    )
                    _notified[key] = True
                elif avg < THRESHOLDS[key]:
                    _notified[key] = False

            # ── Save to DB once per interval ──
            if now - last_save >= DB_SAVE_INTERVAL:
                cur_net = psutil.net_io_counters()
                dt = now - last_net["time"]
                sent_mbs = (cur_net.bytes_sent - last_net["sent"]) / dt / (1024 * 1024)
                recv_mbs = (cur_net.bytes_recv - last_net["recv"]) / dt / (1024 * 1024)

                insert_metric(now, cpu, ram, temp, round(sent_mbs, 4), round(recv_mbs, 4))

                last_net = {"sent": cur_net.bytes_sent, "recv": cur_net.bytes_recv, "time": now}
                last_save = now

            # ── Daily cleanup ──
            if now - last_cleanup >= 86400:
                cleanup_old_data()
                last_cleanup = now

        except Exception as e:
            logger.error(f"metrics_loop: {e}")

        await asyncio.sleep(METRICS_INTERVAL)
