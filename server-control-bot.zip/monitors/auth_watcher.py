"""
Real-time SSH auth monitor.
Watches /var/log/auth.log (fallback: journalctl -u ssh).
Extracts maximum detail: user, IP, port, method, key fingerprint,
invalid user flag. Sends rich Telegram alerts. Logs everything to DB.
"""

import asyncio
import os
import re
import time
from datetime import datetime

from aiogram import Bot

from config import AUTHORIZED_USER_ID, SSH_ALERT_COOLDOWN, is_ssh_notify_active, logger
from database import (
    insert_ssh_event,
    get_failed_ssh_stats,
    get_top_failed_ips,
)

# ── Regex patterns ──────────────────────────────────────

# Failed password for [invalid user] USERNAME from IP port PORT ssh2
_FAILED = re.compile(
    r"sshd\[\d+\]:\s+Failed\s+(\w+)\s+for\s+"
    r"(invalid user\s+)?(\S+)\s+from\s+(\S+)\s+port\s+(\d+)"
)

# Accepted METHOD for USERNAME from IP port PORT ssh2[: KEYTYPE FINGERPRINT]
_ACCEPTED = re.compile(
    r"sshd\[\d+\]:\s+Accepted\s+(\w+)\s+for\s+"
    r"(\S+)\s+from\s+(\S+)\s+port\s+(\d+)"
    r"(?:\s+ssh2:\s+(.+))?"
)

# Disconnecting ... Too many authentication failures
_TOO_MANY = re.compile(
    r"sshd\[\d+\]:\s+Disconnecting\s+(?:invalid user\s+)?(\S+)\s+(\S+)\s+port\s+(\d+).*"
    r"Too many authentication failures"
)

# Connection closed by authenticating user USERNAME IP port PORT
_CLOSED = re.compile(
    r"sshd\[\d+\]:\s+Connection closed by\s+(?:authenticating\s+)?(?:invalid\s+)?user\s+"
    r"(\S+)\s+(\S+)\s+port\s+(\d+)"
)

# Invalid user USERNAME from IP port PORT
_INVALID_USER = re.compile(
    r"sshd\[\d+\]:\s+Invalid user\s+(\S+)\s+from\s+(\S+)\s+port\s+(\d+)"
)

# Per-IP cooldown: ip → last_alert_timestamp
_cooldown: dict[str, float] = {}


def _parse_line(line: str) -> dict | None:
    """Parse an auth.log line into a structured event dict, or None."""

    # --- Failed ---
    m = _FAILED.search(line)
    if m:
        return {
            "event_type": "failed",
            "method": m.group(1),
            "invalid_user": bool(m.group(2)),
            "username": m.group(3),
            "ip": m.group(4),
            "port": int(m.group(5)),
            "key_fingerprint": "",
        }

    # --- Accepted ---
    m = _ACCEPTED.search(line)
    if m:
        key_info = m.group(5) or ""
        return {
            "event_type": "accepted",
            "method": m.group(1),
            "invalid_user": False,
            "username": m.group(2),
            "ip": m.group(3),
            "port": int(m.group(4)),
            "key_fingerprint": key_info.strip(),
        }

    # --- Too many auth failures ---
    m = _TOO_MANY.search(line)
    if m:
        return {
            "event_type": "failed",
            "method": "brute-force",
            "invalid_user": "invalid" in line.lower(),
            "username": m.group(1),
            "ip": m.group(2),
            "port": int(m.group(3)),
            "key_fingerprint": "",
        }

    return None


async def _notify_failed(bot: Bot, ev: dict) -> None:
    """Send rich alert for failed SSH login."""
    now = time.time()
    ip = ev["ip"]

    if now - _cooldown.get(ip, 0) < SSH_ALERT_COOLDOWN:
        return
    _cooldown[ip] = now

    total_24h, unique_ips = get_failed_ssh_stats(hours=24)
    top_ips = get_top_failed_ips(hours=24, limit=3)
    dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    invalid_tag = " ⚠️ <i>user does not exist</i>" if ev["invalid_user"] else ""
    method_display = ev["method"]

    top_lines = ""
    if top_ips:
        top_lines = "\n\n🏴‍☠️ <b>Top attackers 24h:</b>\n"
        for tip, cnt in top_ips:
            top_lines += f"  <code>{tip}</code> — {cnt} attempts\n"

    await bot.send_message(
        AUTHORIZED_USER_ID,
        f"🚨 <b>SSH Login Failed!</b>\n"
        f"👤 User: <code>{ev['username']}</code>{invalid_tag}\n"
        f"🌐 IP: <code>{ip}</code>\n"
        f"🔌 Port: {ev['port']}\n"
        f"🔑 Method: {method_display}\n"
        f"📅 {dt}\n\n"
        f"⚠️ Last 24h: <b>{total_24h}</b> failures from <b>{unique_ips}</b> IPs"
        f"{top_lines}",
    )


async def _notify_accepted(bot: Bot, ev: dict) -> None:
    """Send rich alert for successful SSH login."""
    dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    key_line = ""
    if ev["key_fingerprint"]:
        key_line = f"\n🔐 Key: <code>{ev['key_fingerprint']}</code>"

    await bot.send_message(
        AUTHORIZED_USER_ID,
        f"✅ <b>SSH Login Accepted</b>\n"
        f"👤 User: <code>{ev['username']}</code>\n"
        f"🌐 IP: <code>{ev['ip']}</code>\n"
        f"🔌 Port: {ev['port']}\n"
        f"🔑 Method: {ev['method']}"
        f"{key_line}\n"
        f"📅 {dt}",
    )


async def _process_line(bot: Bot, line: str) -> None:
    """Parse, save to DB, optionally notify."""
    ev = _parse_line(line)
    if not ev:
        return

    insert_ssh_event(
        ts=time.time(),
        event_type=ev["event_type"],
        username=ev["username"],
        ip=ev["ip"],
        method=ev["method"],
        port=ev["port"],
        key_fingerprint=ev["key_fingerprint"],
        invalid_user=ev["invalid_user"],
    )

    # Check if notifications are enabled
    if not is_ssh_notify_active():
        return

    if ev["event_type"] == "failed":
        await _notify_failed(bot, ev)
    else:
        await _notify_accepted(bot, ev)


async def _tail_auth_log(bot: Bot) -> None:
    proc = await asyncio.create_subprocess_exec(
        "tail", "-F", "-n", "0", "/var/log/auth.log",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    logger.info("auth_watcher: tailing /var/log/auth.log")

    async for raw in proc.stdout:
        line = raw.decode("utf-8", errors="replace").strip()
        await _process_line(bot, line)


async def _journalctl_ssh(bot: Bot) -> None:
    proc = await asyncio.create_subprocess_exec(
        "journalctl", "-u", "ssh", "-f", "-n", "0", "--no-pager",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    logger.info("auth_watcher: following journalctl -u ssh")

    async for raw in proc.stdout:
        line = raw.decode("utf-8", errors="replace").strip()
        await _process_line(bot, line)


async def auth_watcher_loop(bot: Bot) -> None:
    while True:
        try:
            if os.path.exists("/var/log/auth.log"):
                await _tail_auth_log(bot)
            else:
                await _journalctl_ssh(bot)
        except FileNotFoundError:
            logger.warning("auth_watcher: neither auth.log nor journalctl available, retry in 60s")
        except Exception as e:
            logger.error(f"auth_watcher: {e}")

        await asyncio.sleep(5)
