"""
Watches /var/log/auth.log (or falls back to journalctl -u ssh)
for SSH login events and sends Telegram alerts on failures.
All events (accepted + failed) are stored in the DB.
"""

import asyncio
import re
import time
from datetime import datetime

from aiogram import Bot

from config import AUTHORIZED_USER_ID, SSH_ALERT_COOLDOWN, logger
from database import insert_ssh_event, get_failed_ssh_stats

# ── Regex patterns for sshd messages ────────────────────

_FAILED = re.compile(
    r"sshd\[\d+\]:\s+Failed\s+(\w+)\s+for\s+"
    r"(?:invalid user\s+)?(\S+)\s+from\s+(\S+)\s+port\s+\d+"
)

_ACCEPTED = re.compile(
    r"sshd\[\d+\]:\s+Accepted\s+(\w+)\s+for\s+"
    r"(\S+)\s+from\s+(\S+)\s+port\s+\d+"
)

# Per-IP cooldown tracker: ip → last_alert_timestamp
_cooldown: dict[str, float] = {}


async def _notify_failed(bot: Bot, user: str, ip: str, method: str) -> None:
    now = time.time()
    if now - _cooldown.get(ip, 0) < SSH_ALERT_COOLDOWN:
        return  # throttled
    _cooldown[ip] = now

    total, unique = get_failed_ssh_stats(hours=24)
    dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    await bot.send_message(
        AUTHORIZED_USER_ID,
        f"🚨 <b>SSH Login Failed!</b>\n"
        f"👤 User: <code>{user}</code>\n"
        f"🌐 IP: <code>{ip}</code>\n"
        f"🔑 Method: {method}\n"
        f"📅 {dt}\n\n"
        f"⚠️ Last 24h: <b>{total}</b> failures from <b>{unique}</b> IPs",
    )


async def _notify_accepted(bot: Bot, user: str, ip: str, method: str) -> None:
    dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    await bot.send_message(
        AUTHORIZED_USER_ID,
        f"✅ <b>SSH Login Accepted</b>\n"
        f"👤 User: <code>{user}</code>\n"
        f"🌐 IP: <code>{ip}</code>\n"
        f"🔑 Method: {method}\n"
        f"📅 {dt}",
    )


def _parse_line(line: str) -> tuple | None:
    """Returns (event_type, method, username, ip) or None."""
    m = _FAILED.search(line)
    if m:
        return ("failed", m.group(1), m.group(2), m.group(3))

    m = _ACCEPTED.search(line)
    if m:
        return ("accepted", m.group(1), m.group(2), m.group(3))

    return None


async def _tail_auth_log(bot: Bot) -> None:
    """Tail /var/log/auth.log with -F (follows log rotation)."""
    proc = await asyncio.create_subprocess_exec(
        "tail", "-F", "-n", "0", "/var/log/auth.log",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )

    logger.info("auth_watcher: tailing /var/log/auth.log")

    async for raw in proc.stdout:
        line = raw.decode("utf-8", errors="replace").strip()
        parsed = _parse_line(line)
        if not parsed:
            continue

        event_type, method, user, ip = parsed
        insert_ssh_event(time.time(), event_type, user, ip, method)

        if event_type == "failed":
            await _notify_failed(bot, user, ip, method)
        else:
            await _notify_accepted(bot, user, ip, method)


async def _journalctl_ssh(bot: Bot) -> None:
    """Fallback: follow journalctl -u ssh if auth.log is missing."""
    proc = await asyncio.create_subprocess_exec(
        "journalctl", "-u", "ssh", "-f", "-n", "0", "--no-pager",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )

    logger.info("auth_watcher: following journalctl -u ssh")

    async for raw in proc.stdout:
        line = raw.decode("utf-8", errors="replace").strip()
        parsed = _parse_line(line)
        if not parsed:
            continue

        event_type, method, user, ip = parsed
        insert_ssh_event(time.time(), event_type, user, ip, method)

        if event_type == "failed":
            await _notify_failed(bot, user, ip, method)
        else:
            await _notify_accepted(bot, user, ip, method)


async def auth_watcher_loop(bot: Bot) -> None:
    """Main entry point — tries auth.log, falls back to journalctl."""
    import os

    while True:
        try:
            if os.path.exists("/var/log/auth.log"):
                await _tail_auth_log(bot)
            else:
                await _journalctl_ssh(bot)
        except FileNotFoundError:
            logger.warning("auth_watcher: neither auth.log nor journalctl available, retrying in 60s")
        except Exception as e:
            logger.error(f"auth_watcher: {e}")

        # If the subprocess dies (log rotation edge case, etc.), restart after pause
        await asyncio.sleep(5)
