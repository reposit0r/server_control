"""
Daily apt update check.
Runs once per 24h, sends a Telegram notification listing
all pending packages (if any). Always reports — not only on changes.
"""

import asyncio

from aiogram import Bot

from config import AUTHORIZED_USER_ID, UPDATE_CHECK_INTERVAL, logger


async def _get_upgradable() -> list[str]:
    """Refresh package lists, then return names of upgradable packages."""
    # Quiet refresh (needs sudo, may silently fail)
    try:
        refresh = await asyncio.create_subprocess_exec(
            "sudo", "apt-get", "update", "-qq",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(refresh.wait(), timeout=120)
    except (asyncio.TimeoutError, FileNotFoundError):
        pass

    try:
        proc = await asyncio.create_subprocess_exec(
            "apt", "list", "--upgradable",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
    except (asyncio.TimeoutError, FileNotFoundError):
        return []

    return [
        line.split("/")[0]
        for line in stdout.decode("utf-8", errors="replace").splitlines()
        if "/" in line and not line.startswith("Listing")
    ]


async def _count_security(output_lines: list[str]) -> int:
    """Try to detect security-related upgrades."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "apt", "list", "--upgradable",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
        return sum(1 for l in stdout.decode().splitlines() if "security" in l.lower())
    except Exception:
        return 0


async def updates_loop(bot: Bot) -> None:
    # Initial delay — let the system settle after boot
    await asyncio.sleep(60)

    while True:
        try:
            packages = await _get_upgradable()

            if packages:
                security = await _count_security(packages)
                sec_line = f"🛡 Security: <b>{security}</b>\n" if security else ""

                preview = packages[:30]
                extra = f"\n… +{len(packages) - 30} more" if len(packages) > 30 else ""
                pkg_list = "\n".join(f"• <code>{p}</code>" for p in preview)

                await bot.send_message(
                    AUTHORIZED_USER_ID,
                    f"📦 <b>{len(packages)} pending updates</b>\n"
                    f"{sec_line}\n{pkg_list}{extra}",
                )
                logger.info(f"updates_loop: {len(packages)} upgradable packages reported")
            else:
                logger.info("updates_loop: system is up to date")

        except Exception as e:
            logger.error(f"updates_loop: {e}")

        await asyncio.sleep(UPDATE_CHECK_INTERVAL)
