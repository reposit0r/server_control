import asyncio

from aiogram import Bot

from .metrics import metrics_loop
from .auth_watcher import auth_watcher_loop
from .updates import updates_loop


def start_all_monitors(bot: Bot) -> None:
    asyncio.create_task(metrics_loop(bot))
    asyncio.create_task(auth_watcher_loop(bot))
    asyncio.create_task(updates_loop(bot))
