from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

B = KeyboardButton  # alias


def main_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
        [B(text="📊 System Load"), B(text="ℹ️ Device Info")],
        [B(text="📈 Graphs"),      B(text="🔝 Top Processes")],
        [B(text="🔐 SSH Log"),     B(text="📦 Updates")],
        [B(text="⚙️ Alert Thresholds"), B(text="📋 View Thresholds")],
        [B(text="🔴 Shutdown"),    B(text="♻️ Reboot")],
    ])


def top_sort_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
        [B(text="By CPU"), B(text="By RAM")],
        [B(text="🔙 Cancel")],
    ])


def graph_metric_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
        [B(text="CPU"), B(text="RAM")],
        [B(text="Temperature"), B(text="Network")],
        [B(text="🔙 Cancel")],
    ])


def graph_period_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
        [B(text="1 Hour"), B(text="24 Hours")],
        [B(text="7 Days"), B(text="🔙 Cancel")],
    ])


def confirm_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
        [B(text="✅ Yes, proceed"), B(text="❌ Cancel")],
    ])


def ssh_log_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(resize_keyboard=True, keyboard=[
        [B(text="🗑 Clear SSH Log"), B(text="🔙 Back")],
    ])
