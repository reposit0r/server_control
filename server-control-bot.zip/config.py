import os
import json
import logging
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(BASE_DIR, "ubuntu_bot.log")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
DB_FILE = os.path.join(BASE_DIR, "metrics.db")

BOT_VERSION = "3.0.1"

API_TOKEN = os.getenv("BOT_TOKEN", "")
AUTHORIZED_USER_ID = int(os.getenv("AUTHORIZED_USER_ID", "0"))

if not API_TOKEN:
    raise SystemExit("BOT_TOKEN is not set. Copy .env.example → .env and fill in your token.")

DEFAULT_THRESHOLDS = {"TEMP": 75, "CPU": 90, "RAM": 90, "AVG_TIME": 30}

# --- Intervals ---
METRICS_INTERVAL = 5              # seconds between metric snapshots
DB_SAVE_INTERVAL = 60             # seconds between DB writes
UPDATE_CHECK_INTERVAL = 24 * 3600 # once per day
SSH_ALERT_COOLDOWN = 30           # seconds — suppress repeated alerts from same IP
DATA_RETENTION_DAYS = 90          # auto-cleanup older records

# --- Logging ---
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("server_bot")


def load_thresholds() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            logger.warning("Failed to read config, using defaults")
    return DEFAULT_THRESHOLDS.copy()


def save_thresholds(data: dict) -> None:
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=2)


THRESHOLDS = load_thresholds()
