#!/bin/bash
set -e

DIR="/opt/server-control-bot"
SERVICE="server-control-bot"

cd "$DIR"

OLD_VER=$(grep -oP 'BOT_VERSION\s*=\s*"\K[^"]+' config.py)
echo "Current version: v$OLD_VER"

echo "Pulling from GitHub…"
git pull

NEW_VER=$(grep -oP 'BOT_VERSION\s*=\s*"\K[^"]+' config.py)

if [ "$OLD_VER" = "$NEW_VER" ]; then
    echo "Version unchanged: v$NEW_VER"
else
    echo "Updated: v$OLD_VER → v$NEW_VER"
fi

echo "Restarting $SERVICE…"
sudo systemctl restart "$SERVICE"
sleep 2
sudo systemctl status "$SERVICE" --no-pager -l
