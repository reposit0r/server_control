from __future__ import annotations
import os
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject

from config import AUTHORIZED_USER_ID


# ── Hardware helpers ─────────────────────────────────────

def get_cpu_temp() -> float | None:
    try:
        path = "/sys/class/thermal/thermal_zone0/temp"
        if os.path.exists(path):
            with open(path) as f:
                return round(int(f.read().strip()) / 1000.0, 1)
    except (ValueError, IOError, OSError):
        pass
    return None


# ── Auth middleware ──────────────────────────────────────

class AuthMiddleware(BaseMiddleware):
    """Silently drops messages from unauthorized users."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user and user.id == AUTHORIZED_USER_ID:
            return await handler(event, data)
        return None  # ignore
