from aiogram.fsm.state import State, StatesGroup


class AlertStates(StatesGroup):
    waiting_for_type = State()
    waiting_for_value = State()


class ConfirmAction(StatesGroup):
    waiting_for_confirmation = State()


class GraphStates(StatesGroup):
    waiting_for_metric = State()
    waiting_for_period = State()


class TopStates(StatesGroup):
    waiting_for_sort = State()


class SSHLogStates(StatesGroup):
    waiting_for_action = State()
    waiting_for_clear_confirm = State()
