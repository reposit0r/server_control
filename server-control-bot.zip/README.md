# Server Control Bot

Telegram-бот для мониторинга и управления Ubuntu/Debian сервером.

## Возможности

- **Мониторинг** — CPU, RAM, температура, сеть, диск, uptime
- **Графики** — исторические графики метрик (1ч / 24ч / 7д) из SQLite
- **Топ процессов** — сортировка по CPU или RAM
- **SSH-лог** — все подключения (успешные и неудачные) с мгновенными алертами в Telegram
- **Обновления** — ежедневная проверка apt с уведомлением о pending-пакетах
- **Алерты** — настраиваемые пороги CPU / RAM / Temp со сглаживанием
- **Управление** — shutdown / reboot с подтверждением
- **Безопасность** — middleware авторизации, доступ только указанному user ID

## Структура

```
├── bot.py                 # Точка входа
├── config.py              # Конфигурация, .env, пороги
├── database.py            # SQLite: metrics + ssh_events
├── states.py              # FSM-состояния
├── keyboards.py           # Клавиатуры
├── utils.py               # Хелперы + AuthMiddleware
├── handlers/
│   ├── system.py          # /start, нагрузка, инфо, топ
│   ├── graphs.py          # Графики
│   ├── power.py           # Shutdown / Reboot
│   ├── thresholds.py      # Настройка порогов
│   └── security.py        # SSH-лог, проверка обновлений
└── monitors/
    ├── metrics.py          # Фоновый сбор метрик
    ├── auth_watcher.py     # Мониторинг auth.log / journalctl
    └── updates.py          # Ежедневная проверка apt
```

## Установка

```bash
# Клонировать
git clone https://github.com/YOUR_USER/server-control-bot.git
cd server-control-bot

# Зависимости
pip install -r requirements.txt

# Настроить токен
cp .env.example .env
nano .env  # вписать BOT_TOKEN и AUTHORIZED_USER_ID

# Запустить
python3 bot.py
```

## Деплой как systemd-сервис

```bash
sudo cp -r . /opt/server-control-bot
sudo cp server-control-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now server-control-bot
```

Проверить статус:

```bash
sudo systemctl status server-control-bot
sudo journalctl -u server-control-bot -f
```

## Переменные окружения

| Переменная | Описание |
|---|---|
| `BOT_TOKEN` | Telegram Bot API токен от @BotFather |
| `AUTHORIZED_USER_ID` | Telegram user ID (получить у @userinfobot) |

## Требования

- Python 3.10+
- Ubuntu / Debian (для auth.log и apt)
- Root-доступ (для shutdown/reboot и apt update)

## Лицензия

MIT
