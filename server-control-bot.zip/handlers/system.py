import os
import time
import socket
import platform
from datetime import timedelta

import psutil
from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext

from keyboards import main_kb, top_sort_kb
from states import TopStates
from utils import get_cpu_temp
from config import BOT_VERSION

router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        f"✅ Bot is active.\n🤖 Version: <b>{BOT_VERSION}</b>",
        reply_markup=main_kb(),
    )


@router.message(F.text == "📊 System Load")
async def show_load(message: Message):
    cpu = psutil.cpu_percent(interval=0.3)
    load1, load5, load15 = (round(x, 2) for x in os.getloadavg())
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    uptime = str(timedelta(seconds=int(time.time() - psutil.boot_time())))
    temp = get_cpu_temp()
    t = f"{temp}°C" if temp else "N/A"

    await message.answer(
        f"📊 <b>System Load:</b>\n"
        f"🧠 CPU: {cpu}% (LA: {load1}, {load5}, {load15})\n"
        f"🌡 Temp: {t}\n"
        f"📂 RAM: {ram.percent}% ({round(ram.used/1024**3,1)} / {round(ram.total/1024**3,1)} GB)\n"
        f"🗄 Disk: {disk.percent}% ({round(disk.used/1024**3,1)} / {round(disk.total/1024**3,1)} GB)\n"
        f"⏱️ Uptime: {uptime}",
    )


@router.message(F.text == "ℹ️ Device Info")
async def show_info(message: Message):
    hostname = socket.gethostname()
    kernel = platform.release()
    arch = platform.machine()
    cores = psutil.cpu_count(logical=True)
    ram_gb = round(psutil.virtual_memory().total / 1024**3, 1)

    await message.answer(
        f"ℹ️ <b>Device Info:</b>\n"
        f"🖥 Hostname: <code>{hostname}</code>\n"
        f"💻 OS: {platform.system()} {kernel}\n"
        f"🏗 Arch: {arch}\n"
        f"⚙️ Cores: {cores}\n"
        f"🧠 RAM: {ram_gb} GB\n"
        f"🤖 Bot: v{BOT_VERSION}",
    )


# ── Top Processes ────────────────────────────────────────

@router.message(F.text == "🔝 Top Processes")
async def ask_top_sort(message: Message, state: FSMContext):
    await message.answer("Sort processes by CPU or RAM?", reply_markup=top_sort_kb())
    await state.set_state(TopStates.waiting_for_sort)


@router.message(StateFilter(TopStates.waiting_for_sort))
async def show_top(message: Message, state: FSMContext):
    if message.text == "🔙 Cancel":
        await message.answer("Cancelled.", reply_markup=main_kb())
        await state.clear()
        return

    key = "cpu_percent" if message.text == "By CPU" else "memory_percent"
    procs = []
    for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        try:
            procs.append(p.info)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    procs.sort(key=lambda p: p[key] or 0, reverse=True)

    lines = [f"🔝 <b>Top 10 ({message.text}):</b>\n"]
    for p in procs[:10]:
        lines.append(
            f"<b>{p['name']}</b> (PID {p['pid']})\n"
            f"├ CPU {p['cpu_percent']}% | RAM {round(p['memory_percent'] or 0, 1)}%"
        )

    await message.answer("\n".join(lines), reply_markup=main_kb())
    await state.clear()
