import asyncio
from datetime import datetime

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from keyboards import main_kb, ssh_log_kb, confirm_kb
from states import SSHLogStates
from database import get_ssh_events, get_ssh_count, get_failed_ssh_stats, clear_ssh_events

router = Router()


# ── SSH Log ──────────────────────────────────────────────

@router.message(F.text == "🔐 SSH Log")
async def show_ssh_log(message: Message, state: FSMContext):
    total, accepted, failed = get_ssh_count()
    failed_24h, unique_ips = get_failed_ssh_stats(hours=24)
    events = get_ssh_events(limit=30)

    if not events:
        await message.answer("🔐 No SSH events recorded yet.", reply_markup=main_kb())
        return

    lines = [
        f"🔐 <b>SSH Log</b> (last 30 of {total})\n"
        f"📊 Total: {total} | ✅ {accepted} | ❌ {failed}\n"
        f"⚠️ Failed 24h: <b>{failed_24h}</b> from <b>{unique_ips}</b> IPs\n"
    ]

    for ts, etype, user, ip, method in events:
        dt = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M:%S")
        icon = "✅" if etype == "accepted" else "❌"
        lines.append(f"{icon} <code>{dt}</code> <b>{user}</b>@{ip} ({method})")

    await message.answer("\n".join(lines), reply_markup=ssh_log_kb())
    await state.set_state(SSHLogStates.waiting_for_action)


@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text == "🗑 Clear SSH Log")
async def ask_clear_confirm(message: Message, state: FSMContext):
    total, _, _ = get_ssh_count()
    await message.answer(
        f"⚠️ Delete <b>all {total}</b> SSH log entries?\nThis cannot be undone.",
        reply_markup=confirm_kb(),
    )
    await state.set_state(SSHLogStates.waiting_for_clear_confirm)


@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text == "🔙 Back")
async def ssh_back(message: Message, state: FSMContext):
    await message.answer("OK", reply_markup=main_kb())
    await state.clear()


@router.message(StateFilter(SSHLogStates.waiting_for_action))
async def ssh_action_fallback(message: Message, state: FSMContext):
    await message.answer("Choose an action or press 🔙 Back.", reply_markup=ssh_log_kb())


@router.message(StateFilter(SSHLogStates.waiting_for_clear_confirm))
async def process_clear(message: Message, state: FSMContext):
    if message.text == "✅ Yes, proceed":
        count = clear_ssh_events()
        await message.answer(f"🗑 Deleted <b>{count}</b> SSH log entries.", reply_markup=main_kb())
    else:
        await message.answer("❌ Cancelled.", reply_markup=main_kb())
    await state.clear()


# ── Updates (manual check) ───────────────────────────────

@router.message(F.text == "📦 Updates")
async def show_updates(message: Message):
    await message.answer("🔄 Checking…")

    try:
        proc = await asyncio.create_subprocess_exec(
            "apt", "list", "--upgradable",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
        output = stdout.decode("utf-8", errors="replace")
    except (asyncio.TimeoutError, FileNotFoundError):
        await message.answer("❌ Could not run apt.", reply_markup=main_kb())
        return

    packages = [
        line.split("/")[0]
        for line in output.strip().splitlines()
        if "/" in line and not line.startswith("Listing")
    ]

    if not packages:
        await message.answer("✅ System is up to date.", reply_markup=main_kb())
        return

    preview = packages[:30]
    extra = f"\n… and {len(packages) - 30} more" if len(packages) > 30 else ""
    pkg_list = "\n".join(f"• <code>{p}</code>" for p in preview)

    await message.answer(
        f"📦 <b>{len(packages)} updates available:</b>\n\n{pkg_list}{extra}",
        reply_markup=main_kb(),
    )
