import asyncio
import time
from datetime import datetime

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from config import THRESHOLDS, save_thresholds, is_ssh_notify_active
from keyboards import main_kb, ssh_log_kb, ssh_mute_kb, confirm_kb
from states import SSHLogStates
from database import (
    get_ssh_events, get_ssh_count, get_failed_ssh_stats,
    get_top_failed_ips, get_usernames_tried, clear_ssh_events,
)

router = Router()

MUTE_DURATIONS = {
    "15 min": 15 * 60,
    "1 hour": 3600,
    "3 hours": 3 * 3600,
    "8 hours": 8 * 3600,
}


def _notify_status_line() -> str:
    """Human-readable notification status."""
    if not THRESHOLDS.get("SSH_NOTIFY", True):
        return "🔕 Alerts: <b>OFF</b>"
    mute_until = THRESHOLDS.get("SSH_MUTE_UNTIL", 0)
    if mute_until > 0 and time.time() < mute_until:
        unmute_at = datetime.fromtimestamp(mute_until).strftime("%H:%M")
        return f"⏸ Alerts: <b>muted until {unmute_at}</b>"
    return "🔔 Alerts: <b>ON</b>"


def _get_ssh_kb():
    notify_on = THRESHOLDS.get("SSH_NOTIFY", True)
    mute_until = THRESHOLDS.get("SSH_MUTE_UNTIL", 0)
    is_muted = mute_until > 0 and time.time() < mute_until
    return ssh_log_kb(notify_on, is_muted)


# ── SSH Log ──────────────────────────────────────────────

@router.message(F.text == "🔐 SSH Log")
async def show_ssh_log(message: Message, state: FSMContext):
    total, accepted, failed = get_ssh_count()
    failed_24h, unique_ips = get_failed_ssh_stats(hours=24)
    events = get_ssh_events(limit=30)

    if not events:
        await message.answer(
            f"🔐 No SSH events recorded yet.\n{_notify_status_line()}",
            reply_markup=_get_ssh_kb(),
        )
        await state.set_state(SSHLogStates.waiting_for_action)
        return

    lines = [
        f"🔐 <b>SSH Log</b> (last 30 of {total})\n"
        f"📊 Total: {total} | ✅ {accepted} | ❌ {failed}\n"
        f"⚠️ Failed 24h: <b>{failed_24h}</b> from <b>{unique_ips}</b> IPs\n"
        f"{_notify_status_line()}\n"
    ]

    for ts, etype, user, ip, method, port, key_fp, inv_user in events:
        dt = datetime.fromtimestamp(ts).strftime("%m-%d %H:%M:%S")
        port_str = f":{port}" if port else ""

        if etype == "accepted":
            icon = "✅"
            extra = ""
            if key_fp:
                extra = f"\n   🔐 {key_fp}"
        else:
            icon = "❌"
            extra = ""
            if inv_user:
                extra = "\n   ⚠️ user not on server"

        lines.append(
            f"{icon} <code>{dt}</code> <b>{user}</b>@{ip}{port_str} ({method}){extra}"
        )

    await message.answer("\n".join(lines), reply_markup=_get_ssh_kb())
    await state.set_state(SSHLogStates.waiting_for_action)


# ── Toggle / Mute ────────────────────────────────────────

@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text.in_({"🔔 Enable alerts", "🔕 Disable alerts"}))
async def toggle_notify(message: Message, state: FSMContext):
    if message.text == "🔔 Enable alerts":
        THRESHOLDS["SSH_NOTIFY"] = True
        THRESHOLDS["SSH_MUTE_UNTIL"] = 0
    else:
        THRESHOLDS["SSH_NOTIFY"] = False
    save_thresholds(THRESHOLDS)

    status = _notify_status_line()
    await message.answer(f"✅ {status}", reply_markup=_get_ssh_kb())


@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text == "🔔 Unmute alerts")
async def unmute_notify(message: Message, state: FSMContext):
    THRESHOLDS["SSH_MUTE_UNTIL"] = 0
    save_thresholds(THRESHOLDS)
    await message.answer(f"✅ {_notify_status_line()}", reply_markup=_get_ssh_kb())


@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text == "⏸ Mute alerts")
async def ask_mute_duration(message: Message, state: FSMContext):
    await message.answer("Mute SSH alerts for:", reply_markup=ssh_mute_kb())
    await state.set_state(SSHLogStates.waiting_for_mute_duration)


@router.message(StateFilter(SSHLogStates.waiting_for_mute_duration))
async def set_mute_duration(message: Message, state: FSMContext):
    if message.text == "🔙 Back":
        await message.answer(f"{_notify_status_line()}", reply_markup=_get_ssh_kb())
        await state.set_state(SSHLogStates.waiting_for_action)
        return

    seconds = MUTE_DURATIONS.get(message.text)
    if not seconds:
        await message.answer("Choose a duration below:", reply_markup=ssh_mute_kb())
        return

    THRESHOLDS["SSH_MUTE_UNTIL"] = time.time() + seconds
    save_thresholds(THRESHOLDS)

    unmute_at = datetime.fromtimestamp(THRESHOLDS["SSH_MUTE_UNTIL"]).strftime("%H:%M")
    await message.answer(
        f"⏸ SSH alerts muted until <b>{unmute_at}</b>\n"
        f"Events still logged to DB.",
        reply_markup=main_kb(),
    )
    await state.clear()


# ── Clear log ────────────────────────────────────────────

@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text == "🗑 Clear SSH Log")
async def ask_clear_confirm(message: Message, state: FSMContext):
    total, _, _ = get_ssh_count()
    await message.answer(
        f"⚠️ Delete <b>all {total}</b> SSH log entries?\nThis cannot be undone.",
        reply_markup=confirm_kb(),
    )
    await state.set_state(SSHLogStates.waiting_for_clear_confirm)


@router.message(StateFilter(SSHLogStates.waiting_for_clear_confirm))
async def process_clear(message: Message, state: FSMContext):
    if message.text == "✅ Yes, proceed":
        count = clear_ssh_events()
        await message.answer(f"🗑 Deleted <b>{count}</b> SSH log entries.", reply_markup=main_kb())
    else:
        await message.answer("❌ Cancelled.", reply_markup=main_kb())
    await state.clear()


# ── Back / fallback ──────────────────────────────────────

@router.message(StateFilter(SSHLogStates.waiting_for_action), F.text == "🔙 Back")
async def ssh_back(message: Message, state: FSMContext):
    await message.answer("OK", reply_markup=main_kb())
    await state.clear()


@router.message(StateFilter(SSHLogStates.waiting_for_action))
async def ssh_action_fallback(message: Message, state: FSMContext):
    await message.answer("Choose an action or press 🔙 Back.", reply_markup=_get_ssh_kb())


# ── Updates (manual check) ───────────────────────────────

@router.message(F.text == "📦 Updates")
async def show_updates(message: Message):
    await message.answer("🔄 Checking…")

    try:
        proc = await asyncio.create_subprocess_exec(
            "apt", "list", "--upgradable",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
        output = stdout.decode("utf-8", errors="replace")
    except (asyncio.TimeoutError, FileNotFoundError):
        await message.answer("❌ Could not run apt.", reply_markup=main_kb())
        return

    packages = [
        line.split("/")[0]
        for line in output.strip().splitlines()
        if "/" in line and not line.startswith("Listing")
    ]

    if not packages:
        await message.answer("✅ System is up to date.", reply_markup=main_kb())
        return

    preview = packages[:30]
    extra = f"\n… and {len(packages) - 30} more" if len(packages) > 30 else ""
    pkg_list = "\n".join(f"• <code>{p}</code>" for p in preview)

    await message.answer(
        f"📦 <b>{len(packages)} updates available:</b>\n\n{pkg_list}{extra}",
        reply_markup=main_kb(),
    )
