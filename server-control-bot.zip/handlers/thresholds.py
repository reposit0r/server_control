from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from config import THRESHOLDS, save_thresholds
from keyboards import main_kb, threshold_type_kb
from states import AlertStates

router = Router()

VALID_TYPES = {"TEMP", "CPU", "RAM", "TIME"}


@router.message(F.text == "⚙️ Alert Thresholds")
async def ask_type(message: Message, state: FSMContext):
    await message.answer("Which threshold to change?", reply_markup=threshold_type_kb())
    await state.set_state(AlertStates.waiting_for_type)


@router.message(StateFilter(AlertStates.waiting_for_type))
async def select_type(message: Message, state: FSMContext):
    if message.text == "🔙 Cancel":
        await message.answer("Cancelled.", reply_markup=main_kb())
        await state.clear()
        return

    t = message.text.strip().upper()
    if t in VALID_TYPES:
        await state.update_data(threshold_type=t)
        await message.answer(f"Enter new value for <b>{t}</b> (current: {THRESHOLDS.get('AVG_TIME' if t == 'TIME' else t)}):")
        await state.set_state(AlertStates.waiting_for_value)
    else:
        await message.answer("❌ Choose a button below:", reply_markup=threshold_type_kb())


@router.message(StateFilter(AlertStates.waiting_for_value))
async def set_value(message: Message, state: FSMContext):
    if message.text == "🔙 Cancel":
        await message.answer("Cancelled.", reply_markup=main_kb())
        await state.clear()
        return

    try:
        val = int(message.text.strip())
    except ValueError:
        await message.answer("❌ Enter a valid integer.")
        return

    data = await state.get_data()
    key = "AVG_TIME" if data["threshold_type"] == "TIME" else data["threshold_type"]
    THRESHOLDS[key] = val
    save_thresholds(THRESHOLDS)
    await message.answer(f"✅ <b>{key}</b> set to <b>{val}</b>", reply_markup=main_kb())
    await state.clear()


@router.message(F.text == "📋 View Thresholds")
async def view_thresholds(message: Message):
    await message.answer(
        f"🔧 <b>Current Thresholds:</b>\n"
        f"🌡 TEMP: {THRESHOLDS['TEMP']}°C\n"
        f"🧠 CPU: {THRESHOLDS['CPU']}%\n"
        f"📂 RAM: {THRESHOLDS['RAM']}%\n"
        f"⏱ Smoothing: {THRESHOLDS['AVG_TIME']}s",
    )
