from aiogram import Dispatcher

from .system import router as system_router
from .graphs import router as graphs_router
from .power import router as power_router
from .thresholds import router as thresholds_router
from .security import router as security_router


def register_all_handlers(dp: Dispatcher) -> None:
    dp.include_router(system_router)
    dp.include_router(graphs_router)
    dp.include_router(power_router)
    dp.include_router(thresholds_router)
    dp.include_router(security_router)
