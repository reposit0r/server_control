import asyncio
import os
import re
import subprocess

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from config import BOT_VERSION, BASE_DIR
from keyboards import main_kb, confirm_kb
from states import UpdateStates

router = Router()


async def _run(*cmd: str) -> tuple[int, str]:
    """Run a command in the bot directory, return (returncode, stdout)."""
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=BASE_DIR,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
    return proc.returncode, stdout.decode("utf-8", errors="replace").strip()


def _read_new_version() -> str:
    """Read BOT_VERSION from config.py on disk (after git pull)."""
    try:
        path = os.path.join(BASE_DIR, "config.py")
        with open(path) as f:
            m = re.search(r'BOT_VERSION\s*=\s*["\']([^"\']+)', f.read())
            return m.group(1) if m else "?"
    except Exception:
        return "?"


@router.message(F.text == "🔄 Update Bot")
async def check_update(message: Message, state: FSMContext):
    await message.answer("🔍 Checking for updates…")

    # Fetch latest from remote
    rc, out = await _run("git", "fetch")
    if rc != 0:
        await message.answer(f"❌ git fetch failed:\n<pre>{out}</pre>", reply_markup=main_kb())
        return

    # Compare local HEAD vs upstream
    _, local_hash = await _run("git", "rev-parse", "HEAD")
    _, remote_hash = await _run("git", "rev-parse", "@{u}")

    if local_hash == remote_hash:
        await message.answer(
            f"✅ Bot is up to date — <b>v{BOT_VERSION}</b>",
            reply_markup=main_kb(),
        )
        return

    # Show new commits
    _, log = await _run("git", "log", "--oneline", "HEAD..@{u}")
    commits = log.strip() or "—"

    # Count commits
    lines = [l for l in commits.splitlines() if l.strip()]
    count = len(lines)
    preview = "\n".join(lines[:15])
    if count > 15:
        preview += f"\n… +{count - 15} more"

    await state.update_data(commit_count=count)
    await message.answer(
        f"📥 <b>{count} new commit(s) available</b>\n"
        f"Current: <b>v{BOT_VERSION}</b>\n\n"
        f"<pre>{preview}</pre>\n\n"
        f"Apply update and restart bot?",
        reply_markup=confirm_kb(),
    )
    await state.set_state(UpdateStates.waiting_for_confirm)


@router.message(StateFilter(UpdateStates.waiting_for_confirm))
async def apply_update(message: Message, state: FSMContext):
    if message.text != "✅ Yes, proceed":
        await message.answer("❌ Update cancelled.", reply_markup=main_kb())
        await state.clear()
        return

    await state.clear()

    # Pull
    rc, out = await _run("git", "pull")
    if rc != 0:
        await message.answer(f"❌ git pull failed:\n<pre>{out}</pre>", reply_markup=main_kb())
        return

    new_version = _read_new_version()

    await message.answer(
        f"✅ Updated: <b>v{BOT_VERSION}</b> → <b>v{new_version}</b>\n"
        f"♻️ Restarting bot…",
        reply_markup=main_kb(),
    )

    # Small delay so the message is delivered before the process dies
    await asyncio.sleep(1)
    subprocess.Popen(["sudo", "systemctl", "restart", "server-control-bot"])
