import subprocess

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from keyboards import main_kb, confirm_kb
from states import ConfirmAction

router = Router()


@router.message(F.text.in_({"🔴 Shutdown", "♻️ Reboot"}))
async def request_action(message: Message, state: FSMContext):
    action = "shutdown" if "Shutdown" in message.text else "reboot"
    await state.update_data(action=action)
    await message.answer(
        f"⚠️ Are you sure you want to <b>{action}</b> the server?",
        reply_markup=confirm_kb(),
    )
    await state.set_state(ConfirmAction.waiting_for_confirmation)


@router.message(StateFilter(ConfirmAction.waiting_for_confirmation))
async def confirm(message: Message, state: FSMContext):
    if message.text == "✅ Yes, proceed":
        data = await state.get_data()
        cmd = (
            ["sudo", "shutdown", "now"]
            if data["action"] == "shutdown"
            else ["sudo", "reboot"]
        )
        await message.answer("🔄 Executing…", reply_markup=main_kb())
        subprocess.Popen(cmd)
    else:
        await message.answer("❌ Cancelled.", reply_markup=main_kb())
    await state.clear()
