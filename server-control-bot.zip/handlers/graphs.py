import io
import time
from datetime import datetime

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from aiogram import Router, F
from aiogram.types import Message, BufferedInputFile
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext

from keyboards import main_kb, graph_metric_kb, graph_period_kb
from states import GraphStates
from database import get_metrics

router = Router()

PERIOD_HOURS = {"1 Hour": 1, "24 Hours": 24, "7 Days": 168}


@router.message(F.text == "📈 Graphs")
async def ask_metric(message: Message, state: FSMContext):
    await message.answer("Select metric to plot:", reply_markup=graph_metric_kb())
    await state.set_state(GraphStates.waiting_for_metric)


@router.message(StateFilter(GraphStates.waiting_for_metric))
async def ask_period(message: Message, state: FSMContext):
    if message.text == "🔙 Cancel":
        await message.answer("Cancelled.", reply_markup=main_kb())
        await state.clear()
        return
    await state.update_data(metric=message.text)
    await message.answer("Select period:", reply_markup=graph_period_kb())
    await state.set_state(GraphStates.waiting_for_period)


@router.message(StateFilter(GraphStates.waiting_for_period))
async def send_graph(message: Message, state: FSMContext):
    if message.text == "🔙 Cancel":
        await message.answer("Cancelled.", reply_markup=main_kb())
        await state.clear()
        return

    data = await state.get_data()
    metric = data["metric"]
    period = message.text
    hours = PERIOD_HOURS.get(period, 1)

    rows = get_metrics(time.time() - hours * 3600)
    if not rows:
        await message.answer("Not enough data yet.", reply_markup=main_kb())
        await state.clear()
        return

    ts = [datetime.fromtimestamp(r[0]) for r in rows]

    fig, ax = plt.subplots(figsize=(10, 5))

    if metric == "CPU":
        ax.plot(ts, [r[1] for r in rows], color="#e74c3c", lw=2)
        ax.set_ylabel("CPU %")
    elif metric == "RAM":
        ax.plot(ts, [r[2] for r in rows], color="#3498db", lw=2)
        ax.set_ylabel("RAM %")
    elif metric == "Temperature":
        ax.plot(ts, [r[3] for r in rows], color="#e67e22", lw=2)
        ax.set_ylabel("Temp °C")
    elif metric == "Network":
        ax.plot(ts, [r[4] for r in rows], color="#2ecc71", label="Sent MB/s", lw=1.5)
        ax.plot(ts, [r[5] for r in rows], color="#9b59b6", label="Recv MB/s", lw=1.5)
        ax.set_ylabel("Speed (MB/s)")
        ax.legend()

    ax.set_title(f"{metric} — {period}")
    ax.grid(True, ls="--", alpha=0.6)
    fmt = "%H:%M" if hours <= 24 else "%m-%d"
    ax.xaxis.set_major_formatter(mdates.DateFormatter(fmt))
    fig.autofmt_xdate()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    plt.close(fig)

    photo = BufferedInputFile(buf.read(), filename="chart.png")
    await message.answer_photo(
        photo=photo,
        caption=f"📊 {metric} — last {period}",
        reply_markup=main_kb(),
    )
    await state.clear()
